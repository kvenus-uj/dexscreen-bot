To run project
npm install
npm start
